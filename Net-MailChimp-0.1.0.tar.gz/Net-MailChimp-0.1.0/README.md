# Net-MailChimp

Lightweight interface for using MailChimp API in Perl

See Net::MailChimp on CPAN for now.
